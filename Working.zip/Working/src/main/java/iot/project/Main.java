package iot.project;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import de.uniluebeck.itm.util.logging.Logging;
import iot.project.CoordinateTransformExample.CoordinateTransformHelper;

public class Main {
	static int webServerPort = 8080;
	static Map<String, Double> weatherData = new HashMap<String, Double>();

	private static final double MIN_LAT = 41.681389;
	private static final double MAX_LAT = 83.111389;
	private static final double MIN_LON = -141.001944;
	private static final double MAX_LON = -52.619444;

	static {
		Logging.setLoggingDefaults();
	}

	public static void main(String[] args) throws Exception {
		// Obtain an instance of a logger for this class
		Logger log = LoggerFactory.getLogger(Main.class);

		// Start a web server
		setupWebServer(webServerPort);
		log.info("Web server started on port " + webServerPort);
		log.info("Open http://localhost:" + webServerPort + " and/or http://localhost:" + webServerPort + "/hello");

		// starting the data stream
		WeatherStreaming.streamData();
	}

	public static String generateXYkey(double latitude, double longitude) throws Exception {

		CoordinateTransformHelper transformation = new CoordinateTransformHelper("EPSG:4326", "EPSG:3857");
		double[] minLonLat = { MIN_LON, MIN_LAT };
		double[] maxLonLat = { MAX_LON, MAX_LAT };
		GridHelper gridHelper = new GridHelper(transformation, minLonLat, maxLonLat, 450);

		int[] xy = gridHelper.toGrid(latitude, longitude);
		String key = xy[0] + " - " + xy[1];

		return key;
	}

	public static void setupWebServer(int webServerPort) {
		// Set the web server's port
		spark.Spark.port(webServerPort);

		// Serve static files from src/main/resources/webroot
		spark.Spark.staticFiles.location("/webroot");

		// Return "Hello World" at URL /hello
		spark.Spark.get("/hello", (req, res) -> "Hello World");

		// http://localhost:8080/status?lat=32&long=31
		spark.Spark.get("/status", (req, res) -> {
			weatherData = WeatherStreaming.smileyValueMap;

			String latitude = req.queryParams("lat");
			String longitude = req.queryParams("long");

			System.out.println(latitude + " " + longitude);

			String gridPosition = generateXYkey(Double.parseDouble(latitude), Double.parseDouble(longitude));

			System.out.println(gridPosition);

			// get value from weatherData for gridPosition
			boolean validGridPosition = false;
			Double weatherConditionAtGridPosition = 0.0;

			weatherConditionAtGridPosition = weatherData.get(gridPosition);
			if (weatherConditionAtGridPosition == null) {
				weatherConditionAtGridPosition = 0.0;
				validGridPosition = true;
				System.out.println("weather condition at grid: " + weatherConditionAtGridPosition);
			} else {
				System.out.println("No value for grid position: " + gridPosition);
			}

			// calculate "smiley"
			int weatherStatus;
			if (validGridPosition)
				weatherStatus = getWeatherStatus(weatherConditionAtGridPosition);
			else
				weatherStatus = 0;

			return weatherStatus;
		});

		// Wait for server to be initialized
		spark.Spark.awaitInitialization();
	}

	private static boolean isBetween(double lower, double upper, double valueSearched) {
		return lower <= valueSearched && valueSearched < upper;
	}

	private static int getWeatherStatus(double weatherConditionAtGridPosition) {
		// Smiley Algorithm
		int weatherStatus;

		if (isBetween(5, 100, weatherConditionAtGridPosition))
			weatherStatus = 3;
		else if (isBetween(0, 5, weatherConditionAtGridPosition))
			weatherStatus = 2;
		else if (isBetween(-100, 0, weatherConditionAtGridPosition))
			weatherStatus = 1;
		else
			weatherStatus = 0;

		return weatherStatus;
	}
}
