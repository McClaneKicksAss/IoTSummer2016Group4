package iot.project;

import iot.project.CoordinateTransformExample.CoordinateTransformHelper;

public class GridHelper {
	
	// EPSG:3857 is a Spherical Mercator projection coordinate system popularized by web services such as Google and later
		// OpenStreetMap (http://wiki.openstreetmap.org/wiki/EPSG:3857)
		CoordinateTransformHelper transformation;
		private double dx;
		private double dy;
		private double gridSizeX;
		private double gridSizeY;
		private double[] max;
		private double[] min;

		public GridHelper(CoordinateTransformHelper transformation, double minLonLat[], double maxLonLat[], double gridElements)
				throws Exception {

			this.transformation = transformation;

			this.max = transformation.transform(maxLonLat);
			this.min = transformation.transform(minLonLat);

			this.dx = max[0] - min[0];
			this.dy = max[1] - min[1];
			this.gridSizeX = dx / gridElements;
			this.gridSizeY = dy / gridElements;

		}

		int[] toGrid(double lat, double lon) throws Exception {

			double[] xyCoords = transformation.transform(new double[] { lat, lon });
			xyCoords[0] -= this.min[0];
			xyCoords[1] -= this.min[1];

			return new int[] { (int) (xyCoords[0] / this.gridSizeX), (int) (xyCoords[1] / this.gridSizeY) };
		}

}