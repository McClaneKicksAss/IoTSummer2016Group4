package iot.project;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import de.uniluebeck.itm.util.logging.Logging;
import iot.project.CoordinateTransformExample.CoordinateTransformHelper;

public class Main {
	static int webServerPort = 8080;
	static Map<String, Double> weatherData = new HashMap<String, Double>();
	
	private static final double MIN_LAT = 41.681389;
	private static final double MAX_LAT = 83.111389;
	private static final double MIN_LON = -141.001944;
	private static final double MAX_LON = -52.619444;
	
	static {
		Logging.setLoggingDefaults();
	}

	public static void main(String[] args) throws Exception {
		// Obtain an instance of a logger for this class
		Logger log = LoggerFactory.getLogger(Main.class);
		
		
		
		
//		Map<String, Integer> weatherData = new HashMap<String, Integer>();
//		weatherData = WeatherStreaming.smileyValueMap;
		/*
		weatherData.put("1 1", 12.2);
		weatherData.put("1 2", 15.2);
		weatherData.put("1 3", -12.2);
		weatherData.put("2 1", -5.2);
		System.out.println(weatherData);
		*/

		// Start a web server
		setupWebServer(webServerPort);
		log.info("Web server started on port " + webServerPort);
		log.info("Open http://localhost:" + webServerPort + " and/or http://localhost:" + webServerPort + "/hello");
		
		WeatherStreaming.streamData();

		// Do your stuff here

	}
	
	public static String generateXYkey(double latitude, double longitude) throws Exception{
		
		CoordinateTransformHelper transformation = new CoordinateTransformHelper("EPSG:4326", "EPSG:3857"); 
		double[] minLonLat = {MIN_LON, MIN_LAT};
		double[] maxLonLat = {MAX_LON, MAX_LAT};
		GridHelper gridHelper = new GridHelper(transformation, minLonLat, maxLonLat, 450);
		
		int[] xy = gridHelper.toGrid(latitude, longitude);
		String key = xy[0] + " - " + xy[1];
		//System.out.println(key);
		return key;
	}
	
	public static void setupWebServer(int webServerPort) {
        // Set the web server's port
        spark.Spark.port(webServerPort);

        // Serve static files from src/main/resources/webroot
        spark.Spark.staticFiles.location("/webroot");

        // Return "Hello World" at URL /hello
        spark.Spark.get("/hello", (req, res) -> "Hello World");

        // http://localhost:8080/status?lat=32&long=31
        spark.Spark.get("/status", (req, res) -> {
        	weatherData = WeatherStreaming.smileyValueMap;
        	
            String latitude = req.queryParams("lat");
            String longitude = req.queryParams("long");            
            
            String gridPosition = generateXYkey(
            		Double.parseDouble(latitude), 
            		Double.parseDouble(longitude));
            
            // get value from weatherData for gridPosition
            String weatherConditionAtGridPosition = null;
            try {
            	weatherConditionAtGridPosition = weatherData.get(gridPosition).toString();
            }
            catch (Exception e) {
            	System.out.println("No value for grid position: " + gridPosition);
            	weatherConditionAtGridPosition = "99999";
            }
            
//          calculate "smiley"
            String weatherStatus = getWeatherStatus(weatherConditionAtGridPosition);            	            
            
            return weatherStatus;

            //coordinateList.add(new Coordinate(latitude, longitude));
            
            //System.out.println("lat = " + latitude + " long = " + longitude);
            
            
            
//            for (Coordinate c : coordinateList)
//            	System.out.println(c);

            //return coordinateList.toString();
        });

        // Wait for server to be initialized
        spark.Spark.awaitInitialization();
    }
	
	private static boolean isBetween(double lower, double upper, double valueSearched) {
		return lower <= valueSearched && valueSearched <= upper;
	}

	private static String getWeatherStatus(String weatherConditionAtGridPosition) {		
		// Smiley Algorithm
		double weatherCondition = Double.parseDouble(weatherConditionAtGridPosition);
		String weatherStatus;
		
		if(isBetween(10, 100, weatherCondition))
			weatherStatus = "good";
		else if(isBetween(0, 10, weatherCondition))
			weatherStatus = "avg";
		else if(isBetween(-100, 0, weatherCondition))
			weatherStatus = "bad";
		else
			weatherStatus = "unknown";
		
		return weatherStatus;
	}
	
	/* MAP */
	/*
	 * key = String of X and Y grid position
	 * value = int || double
	 */

}
